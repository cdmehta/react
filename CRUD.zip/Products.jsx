import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

function Products() {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    console.log("Component Component mounted");

    setIsLoading(true);
    fetch(`https://fakestoreapi.com/products`)
      .then((resp) => {
        return resp.json();
      })
      .then((data) => {
        setData(data);
        setIsLoading(false);
      }).catch(e => {
        setIsLoading(false)
      }) 

    return () => {
      console.log("component unmounted");
    };
  }, []);

  const navigate = useNavigate();

  return (
    <div className="container">
      <h1>Products</h1>
      {
        isLoading && <h1>Loading...</h1>
      }
      {data.map((item) => {
        return (
          <div key={item.id}>
            <h1>{item.title}</h1>
            <h4>Product id: {item.id}</h4>
            <button
              onClick={() => navigate(`/product/${item.id}`, { state: item })}
            >
              Go to product
            </button>
            {/* <Link to={`/product/${item.id}`}>Go to Product</Link> */}
          </div>
        );
      })}
    </div>
  );
}

export default Products;
