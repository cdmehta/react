import React,{useEffect,useState} from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'

function Product() {
    const params =  useParams()
    // const [data, setData] = useState({})

    const location = useLocation()

    const {state : data} = location

    const navigate = useNavigate()

    // useEffect(() => {
    //   console.log("Component Component mounted");
      
    //   let l="https://fakestoreapi.com/products/"+params.id;
    // //   document.write(l);
    //   fetch(l).then((resp) => {
    //     console.log(resp);
    //     return resp.json()
    //   }).then(data => setData(data))
  
    //   return () => {
    //       console.log("component unmounted")
    //   }
    // },[params.id]) 
    
    
    return(
        <div> 
        <button onClick={() => navigate(-1)}>back</button>
        {    
   
              <div className='container'> 
              <h1>{data.title}</h1>
              
                <img src={data.image} alt="" height="65"width="65" />
                <h2>Price{data.price}</h2>
                <p>{data.description}</p>
                
              </div>
        }
   
</div>
)
        }
    
export default Product