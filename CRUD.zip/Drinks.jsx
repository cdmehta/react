import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

function Drinks() {
  const [drinksList, setDrinksList] = useState([
    { id: 1, name: "cocktail" },
    { id: 2, name: "jamoon" },
    { id: 3, name: "vodka" },
  ]);

  const [categoryList, setCategoryList] = useState([])
  const [isEdit, setIsEdit] = useState(false)


  function fetchCategory() {
    axios.get('http://localhost:8000/category/categorys').then((resp) => {
      if(resp.data) {
        setCategoryList(resp.data.data.categories);
      }
    })
  }

  useEffect(() => {
    fetchCategory()
  }, [])


  const navigate = useNavigate()

  function deleteCategory(id) {
    console.log(id)
    axios.delete(`http://localhost:8000/category/${id}`).then(resp => fetchCategory())
  }

  const [categoryName, setCategoryName] = useState("")

  function handleSubmit(e) {
    e.preventDefault()
    let formData = {
      "name" : categoryName
  }
    axios.post(`http://localhost:8000/category` , formData).then((resp) => {
      if(resp.status === 200) {
        fetchCategory()
        setCategoryName("")
      }
    }).catch((err) => alert(err.response.data.message))
  }

  function editCategory(data) {
    console.log(data)
    setIsEdit(true)
    setCategoryName(data.name)
  }

  function handleUpdate(e) {
    e.preventDefault()
    console.log(categoryName)
  }

  return (
    <div className="container">
      <h1>Drinks</h1>

      <form>
        <input type="text" className="form-control" value={categoryName} onChange={ (e) => setCategoryName(e.target.value) } />
        
        {
          isEdit ? <button className="btn btn-warning" onClick={handleUpdate}>Update</button> :  <button className="btn btn-primary" onClick={handleSubmit}>Submit</button>
        }
      </form>

      <div>


      {
        categoryList.map((item) => {
            return (
                <div key={item._id}>
                    <h1>{item.name}</h1>
                    <h4>Category id: {item._id}</h4>
                    <button onClick={() => deleteCategory(item._id)}>Delete</button>
                    <button onClick={() => editCategory({name: item.name, id: item._id})}>Edit</button>
                    {/* <button onClick={() => navigate(`/drink/${item._id}` , { state: item })}>Go to drink</button> */}
                    {/* <Link to={`/drink/${item._id}`}>Go to drink</Link>  */}
                </div>
            )
        })
      }
      </div>
      
    </div>
  );
}

export default Drinks;
