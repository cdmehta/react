import axios from 'axios'
import React, { useEffect } from 'react'
import { useLocation, useParams } from 'react-router-dom'

function Drink() {

  // const location = useLocation()

  // const {state} = location
  // console.log(state)

  useEffect(() => {
    axios.get('http://localhost:8000/category/categorys').then((resp) => console.log(resp))
  }, [])

  const params =  useParams()
  return (
    <div className='container'>

        {/* <h1>Drink data : {params.id}</h1>
        <h2> drink name: {state.name} </h2> */}
    </div>
  )
}

export default Drink