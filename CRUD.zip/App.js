import React from "react";
import { Route,Routes } from "react-router-dom";
import About from "./About";
import Contact from "./Contact";
import Error from "./Error";
import Navbar from "./Navbar";
import Drinks from "./Drinks";
import Drink from "./Drink";
import Products from "./Products";
import Product from "./Product";
import './index.css'

const App=()=>{
  return (
    <>
    <Navbar/>
    <Routes >
        <Route path="/about" element={<About/>}/>
        <Route path="/contact" element={<Contact/>}/>
        <Route path="/drinks" element={<Drinks />} />
        <Route path="/drink/:id" element={<Drink />} />
        
        <Route path="/products" element={<Products />} />
        <Route path="/product/:id" element={<Product />} />
        
      <Route path="*" element={<Error/>}/>
    </Routes>
{/*        
       <About/>
       <Contact/> */}
    </>
  );
}
export default App;