import React from "react";
class Demo extends React.Component
{
    render()
    {
        return "This is Class Componenet";
    }
}
export default Demo;