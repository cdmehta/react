import React, { useState } from "react";

const Gettime=()=>{
    let newTime=new Date().toLocaleTimeString();
    const [ctime,setCtime]=useState(newTime);

    const updateTime=()=>{
    let newTime=new Date().toLocaleTimeString();
        setCtime(newTime);
    }
    return (
        <>
            <h1>{ctime}</h1>
            <button onClick={updateTime}>Get Time</button>
        </>
    );
}

export default Gettime;