import React, { useState } from "react";
const Forms=()=>{

    const [name,setName]=useState();

    const inputEvent=(event)=>{
        console.log(event.target.value);
        setName(event.target.value); 
    }
    return (
        <>
            <div>
                <h1>Name : {name}</h1>
                <input type='text' placeholder="Enter Your Name" onChange={inputEvent}/>
                <button type="submit">Click Me</button>
            </div>
        </>

    );
}

export default Forms;