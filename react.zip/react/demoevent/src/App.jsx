import React, { useState } from "react";

// const App=()=>{
//     const purple="#8e44ad";
//     const [bg,setBg]=useState(purple);
//     const bgChange=()=>{
//         console.log("Click");
//         let newBg='#34495e';
//         setBg(newBg);

//     }
    
//     return(
//         <>
//             <div style={{backgroundColor:bg}}>
//                 <button onClick={bgChange}>Click Me</button>
//             </div>
//         </>
//     );
// }



//Hooks

//let count=1;
    
const App=()=>{
    const [count,setCount]=useState(1);

    const IncNum=()=>{
        
        setCount(count+1);
    } 
    return (
        <>
            <h1>{count}</h1>
            <button onClick={IncNum}>Click Me</button>
        </>
    );
}
export default App;