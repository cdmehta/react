import React from "react";
function Fun()
{
    return "Fun";
}
export default Fun;