import React, { useState } from "react";
const Login=()=>{

    const [fullname,setFullName]=useState({
        fname:"",
        pass:"",
    });
    const inputEvent=(event)=>{
      //  console.log(event.target.value);
    //   event.target.name
    const value=event.target.value;
    const name=event.target.name;

    setFullName((preVal)=>{
            console.log(preVal);
    })
    }
    const onSubmit=(event)=>{
        event.preventDefault();
        alert();
    }
    return (
        <>
        <form onSubmit={onSubmit}>
            <div>
                <h1>Name :{fullname.fname} {fullname.pass} </h1>
                <input type='text' placeholder="Enter Your Name" name="fname" onChange={inputEvent} value={fullname.fname}/>
                <input type='text' placeholder="Enter Your Password" name="pass" onChange={inputEvent} value={fullname.pass}/>
                <button type="submit" >Click Me</button>
            </div>
            </form>
        </>

    );
}

export default Login;