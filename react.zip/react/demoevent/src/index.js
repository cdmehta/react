import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
// import App from './App';
// import Demo from './Demo';
// import Fun from './Fun';
import reportWebVitals from './reportWebVitals';
// import List from './List'
// import Gettime from './Gettime'
// import Dwatch from './Dwatch';
// import Forms from './Forms';
// import FormSub from './FormSub';
import Login from './Login';

// const Magic=()=>{
// const n=0;
// if(n===10)
//   return <Demo/>;
//   else
//   return <Fun/>
// }

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <App /> */}
    {/* <Demo/>
    <Fun/> */}
    {/* <List/> */}
    {/* <Magic/> */}
    {/* <Gettime/> */}
    {/* <Dwatch/> */}
    {/* <Forms/> */}
    {/* <FormSub/> */}
    <Login/>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
