function List()
{
    const cars = ['Ford', 'BMW', 'Audi'];

    return (
        <>
            <h1>Who lives in my garage?</h1>
      <ul>
        {cars.map((car) => <List brand={car} />)}
      </ul>
        </>
    );
}

export default List;