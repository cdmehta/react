import React from "react";

function Main(){
    return (
        <ol>
            <li>Chirag</li>
            <li>Minesh</li>
        </ol>
    );
}
export default Main;