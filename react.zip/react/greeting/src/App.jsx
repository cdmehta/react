import React from "react";
import Heading from "./Heading";
import Main from "./Main";
function App(){
    return ( 
        <>
    <Heading></Heading>
    <Main></Main>
    </>
    );
}
export default App;