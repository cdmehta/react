import  React from 'react';
 import { createRoot } from 'react-dom/client';
 import './index.css';
const img1='https://picsum.photos/200/320';
const img2='https://picsum.photos/200/330';
const img3='https://picsum.photos/200/340';

//  const date= new Date().toLocaleDateString();
// const time=new Date().toLocaleTimeString();
 
 

 const container = document.getElementById('root');
const root = createRoot(container); // createRoot(container!) if you use TypeScript
root.render(<>
   <h1 className="heading">Chirag</h1>
   {/* Current Date is {date}
   Current Date is {time} */}
   <div className='img_div'> 
   <img src={img1} alt="NoImage" />
   <img src={img2} alt="NoImage" />
   <img src={img3} alt="NoImage" />
   </div>
   </>
   );