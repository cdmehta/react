import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import name from './App';
import add,{sub,mul,div} from './Cal';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <>
    <ol>
      <li>{name}</li>
      <li>{add(4,4)}</li>
      <li>{sub(4,4)}</li>
      <li>{mul(4,4)}</li>
      <li>{div(4,4)}</li>
      </ol>
    </>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
