import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { changeUserFirstName } from '../reduxStore/slices/UserSlice'

function ComponentA() {

  const dispatch = useDispatch()
  useSelector((state) => console.log(state.userSlice))

  const userName = useSelector((state) => state.userSlice.userName)

  return (
    <div>
      <h1>{userName}</h1>
      <button onClick={() => dispatch(changeUserFirstName())}>Click</button>
    </div>
  )
}

export default ComponentA