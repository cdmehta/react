import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { increment } from '../reduxStore/slices/CounterSlice'

function ComponentB() {
  const dispatch =  useDispatch()

  const number =  useSelector((state) => state.CounterSlice.number)


  return (
    <div>
        <h1>{number}</h1>
        <button onClick={() => dispatch(increment())}>+</button>
    </div>
  )
}

export default ComponentB