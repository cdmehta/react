import React from 'react'
import ComponentB from './ComponentB'
import ComponentA from './ComponentA'

function Main() {
  return (
    <div>
        <ComponentA />
        <ComponentB />
    </div>
  )
}

export default Main