import { configureStore } from '@reduxjs/toolkit'
import userSlice from "./slices/UserSlice"
import CounterSlice from './slices/CounterSlice'

export const store = configureStore({
    reducer: {
        userSlice,
        CounterSlice
    },
})
  
  