import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    userName: "Parth",
    userLastName: ""
}

const userSlice = createSlice({
    name: "User",
    initialState,
    reducers: {
        changeUserFirstName: (state, action) => {
            state.userName = "Karan"
        },
        changeUserLastName: (state, action) => {
            state.userLastName = "Katri"
        }
    },
})

export const { changeUserFirstName, changeUserLastName } = userSlice.actions

export default userSlice.reducer