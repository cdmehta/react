import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const initialState = {
    number: 0
}

const counterSlice = createSlice({
    name: "counter",
    initialState,
    reducers: {
        increment: (state, action) => {
            state.number = state.number + 1 
        }
    }
})

export const { increment } = counterSlice.actions
export default counterSlice.reducer